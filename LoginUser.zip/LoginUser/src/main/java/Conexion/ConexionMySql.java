/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionMySql {
    Connection cn;

    // Método para obtener la conexión
    public Connection conectar(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/UsuariosDB","root","Emma_Sofia0529");
            System.out.println("CONECTADO");
        }
        catch(Exception e){
            System.out.println("ERROR DE CONEXION DB"+e);
        }
        return cn;
        }
}